package Broker;

import Assistant.FileAssistant;
import Assistant.FileLocker;
import Assistant.Sleep;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.HashMap;

public class TopicWriter {
    private RandomAccessFile buffer;
    private Topic topic;
    private HashMap<String, Transaction> transactions;

    TopicWriter(Topic topic) {
        this.topic=topic;
        transactions = new HashMap<>();
    }

    public void put(String producerName, int value) {
        if(value <= 0) {
            handleTransactionOperation(producerName, value);
        }
        else {
            handleInsertOperation(producerName, value);
        }
    }

    private void handleTransactionOperation(String producerName, int value) {
        switch (value) {
            case 0:
                startTransaction(producerName);
                break;
            case -1:
                commitTransaction(producerName);
                break;
            case -2:
                cancelTransaction(producerName);
        }
    }
    private void handleInsertOperation(String producerName, int value) {
        if(transactions.containsKey(producerName)) {
            transactions.get(producerName).put(value);
        }
        else {
            this.lockFile();
            writeValue(0);
            writeValue(value);
            writeValue(-1);
            this.releaseLock();
        }
    }
    private void addTransaction(String producerName) {
        transactions.put(producerName, new Transaction(this, producerName));
        Logger.writeLog("OBJECT", "new transaction created by " + producerName);
    }

    /**
     * This method is used to start a transaction for putting a transaction of values inside the buffer.
     * @return Nothing.
     */
    private void startTransaction(String producerName) {
        if(transactions.containsKey(producerName)) {
            Logger.writeLog("Error", producerName + " Didn't finalize its last transaction");
            commitTransaction(producerName);
            transactions.remove(producerName);
        }
        addTransaction(producerName);
    }

    /**
     * This method is used to end the transaction for putting a its values inside the file.
     * @return Nothing.
     */
    private void commitTransaction(String producerName) {
        if(transactions.containsKey(producerName)) {
            transactions.get(producerName).commit();
        }
        else {
            Logger.writeLog("Error", producerName + " tried to commit a non-existing transaction");
        }
    }

    /**
     * This method is used to cancel a transaction.
     * @return Nothing.
     */
    private void cancelTransaction(String producerName) {
        if(transactions.containsKey(producerName)) {
            transactions.remove(producerName);
        }
        else {
            Logger.writeLog("Error", producerName + " tried to cancel a non-existing transaction");
        }
    }

    public void lockFile() {
        while (true) {
            if(FileLocker.isLocked(topic.getTopicFile(), "writer")) {
                Sleep.sleepFor(20L);
                continue;
            }
            if(FileLocker.lockFile(topic.getTopicFile(), "writer"))
                break;
        }
    }
    public void releaseLock() {
        FileLocker.unlockFile(topic.getTopicFile());
    }


    public void writeValue(int value) {
        if(buffer == null)
            buffer = FileAssistant.getRAF(topic.getTopicFile());
        try {
            System.out.println(value);
            buffer.seek(buffer.length());
            buffer.writeInt(value);
            Logger.writeLog("WRITE", value + " is written into " + topic.getTopicFile().getName());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
