package Broker;

import Assistant.FileAssistant;
import Assistant.FileLocker;
import Assistant.Sleep;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Random;

public class TopicReader {

    private RandomAccessFile topicFile;

    private Topic topic;
    private String groupName;
    private String occupiedBy = "";

    TopicReader(Topic topic, String groupName) {
        this.topic = topic;
        this.groupName = groupName;
        topicFile = FileAssistant.getRAF(topic.getTopicFile());
    }

    private boolean checkAccess(String consumerName) {
        if(occupiedBy.equals("")) {
            return true;
        } else if(occupiedBy.equals(consumerName)) {
            return true;
        }
        return false;
    }

    public void lockFile(String locker) {
        while (true) {
            Random random = new Random(System.currentTimeMillis());
            Sleep.sleepFor(random.nextLong()%100+20);
            if(FileLocker.isLocked(topic.getTopicFile(), locker)) {
                continue;
            }
            if (FileLocker.lockFile(topic.getTopicFile(), locker))
                break;
        }
    }

    public void releaseLock() {
        FileLocker.unlockFile(topic.getTopicFile());
    }

    public int get(String consumerName) {
        if(!checkAccess(consumerName) || FileLocker.isLocked(topic.getTopicFile(), consumerName))
            return 0;
        this.lockFile(consumerName);
        if(FileLocker.isLocked(topic.getTopicFile(), consumerName))
            return 0;
        occupiedBy = consumerName;

        int value = 0;
        try {
            value = topicFile.readInt();

        } catch (IOException e) {
            this.releaseLock();
            return 0;
        }

        if(value == -1) {
            this.releaseLock();
            occupiedBy = "";
            return 0;
        }
        System.out.println("XAXXXXXXXX" + value + " " + consumerName);
        Logger.writeLog("READ", consumerName + " read a massage with value: " + value);
      //  this.releaseLock();
        return value;
    }
}