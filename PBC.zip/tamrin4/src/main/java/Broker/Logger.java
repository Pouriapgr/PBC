package Broker;

import Assistant.FileAssistant;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Logger {
    static private File logFile;

    public static void setLogFile() {
        logFile = new File(FileAssistant.getLog());
        FileAssistant.createFile(logFile);
    }
    public static void writeLog(String event, String description) {
        while (true) {
            try {
                FileWriter fileWriter = new FileWriter(logFile, true);
                fileWriter.write(event + ": " + description);
                fileWriter.write(System.getProperty("line.separator"));
                fileWriter.flush();

                fileWriter.close();
                break;

            } catch(IOException e) {
                e.printStackTrace();
            }
        }
    }
}