package Assistant;

import java.io.File;
import java.util.HashMap;

public class FileLocker {
    private static HashMap<String, String> files = new HashMap<>();

    public static boolean isLocked(File file, String locker) {
        if(!files.containsKey(file.getName())) {
            return false;
        }
        else {
            if(files.get(file.getName()).equals("false") || files.get(file.getName()).equals(locker)) {
                return false;
            }
          //  System.out.println(file.getName() + " " + files.get(file.getName()) + " " + locker);
            return true;
        }
    }

    public static boolean lockFile(File file, String locker) {
        if(files.containsKey(file.getName()))
            if(files.get(file.getName()).equals(locker))
                return true;
        if(!isLocked(file, locker)) {
            files.put(file.getName(), locker);
            return true;
        }
        return false;
    }
    public static void unlockFile(File file) {
        files.put(file.getName(), "false");
    }
}
