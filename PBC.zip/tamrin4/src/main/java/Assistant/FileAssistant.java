package Assistant;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class FileAssistant {

    public static void createFile(File file) {
        try {
            if(file.exists())
                file.delete();
            file.createNewFile();

        } catch (IOException e) {
            System.out.println("CANT MAKE FILE " + file.getPath());
        }
    }

    public static RandomAccessFile getRAF(File file) {
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rws");
            return randomAccessFile;
        } catch (IOException e) {
            System.out.println("CANT GET RAF " + file.getPath());
        }
        return null;
    }

    private static String getResources() {
        return System.getProperty("user.dir") + "/src/main/resources";
    }
    public static String findFile(String group, String name) {
        return getResources() + "/" + group + "/" + name;
    }
    public static String getLog() {
        return System.getProperty("user.dir") + "/src/main/java/logs.log";
    }
}
