package Assistant;

public class Sleep {
    public static void sleepFor(Long l) {
        Long now = System.currentTimeMillis();
        while (true) {
            if(System.currentTimeMillis() - now >= l)
                break;
        }
        return;
    }
}
