package Consumer;

import Assistant.FileAssistant;
import Broker.MessageBroker;

import java.io.*;
import java.util.ArrayList;

public class ConsumerGroup extends Thread{
    private ArrayList<Consumer> consumers;
    private MessageBroker messageBroker;
    private String topicName;
    private String groupName;
    private int numberOfConsumers;

    private File consumerGroupFile;
    private FileWriter fileWriter;

    public ConsumerGroup(MessageBroker messageBroker, String topicName, String groupName, File consumerGroupFile, int numberOfConsumers) {
        this.messageBroker = messageBroker;
        this.consumerGroupFile = consumerGroupFile;
        this.topicName = topicName;
        this.groupName = groupName;
        this.numberOfConsumers = numberOfConsumers;
        FileAssistant.createFile(consumerGroupFile);
        consumers = new ArrayList<>();
    }

    private void initialize() throws FileNotFoundException {
        for(int i = 0; i < numberOfConsumers; i++) {
            String consumerName = groupName + "_" + i;
            consumers.add(new Consumer(this, consumerName));
        }
        try {
            fileWriter = new FileWriter(consumerGroupFile, true);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        try {
            initialize();

            for(Consumer consumer: consumers) {
                consumer.start();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void performAction(Consumer consumer, int value) {
        if(value <= 0)
            return;

        try {
            fileWriter.append("Consumer with name " + consumer.getConsumerName() + " read the value " + value);
            fileWriter.append(System.getProperty("line.separator"));
            fileWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getGroupName() {
        return groupName;
    }
    public String getTopicName() {
        return topicName;
    }
    public MessageBroker getMessageBroker() { return messageBroker;    }
}

