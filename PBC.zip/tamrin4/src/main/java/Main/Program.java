package Main;

import Assistant.FileAssistant;
import Broker.MessageBroker;
import Consumer.ConsumerGroup;
import Producer.ProducerGroup;

import java.io.File;

public class Program {

    private String[] args;
    private MessageBroker messageBroker;

    Program(String args[]) {
        this.args = args;
        messageBroker = new MessageBroker();
    }

    private File getProducerGroupDirectory(int x) {
        File producerDirectory = new File("data/");
        if(args.length>0) {
            producerDirectory = new File(args[x]);
        }

        return producerDirectory;
    }

    void run() {
        for (int i = 0; i < args.length; i++) {
            File producerGroupDirectory = getProducerGroupDirectory(i);
            String topicName = producerGroupDirectory.getName();

            File consumerGroupFile = new File(FileAssistant.findFile("received", topicName + ".txt"));
            String consumerGroupName = topicName + "Readers";
            int numberOfConsumers = 4;

            ProducerGroup producerGroup = new ProducerGroup(messageBroker, producerGroupDirectory, topicName);
            ConsumerGroup consumerGroup = new ConsumerGroup(messageBroker, topicName, consumerGroupName, consumerGroupFile, numberOfConsumers);

            producerGroup.start();
            consumerGroup.start();

            Thread thread = new Thread(){
                public void run(){
                    while (producerGroup.isAlive() || consumerGroup.isAlive()) {
                        try {
                            producerGroup.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            };
            thread.start();
        }
    }
}

