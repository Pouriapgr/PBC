package Main;

import Broker.Logger;

public class Main {
    // massages without starting 0 are considered separate transactions
    // change sleep time for better exp
    public static void main(String[] args) {
        Logger.setLogFile();
        new Program(args).run();
    }
}
